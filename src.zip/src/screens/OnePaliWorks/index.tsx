import { View, Image } from 'react-native';
import React, { FC } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';
import COLORS from '../../utils/Colors';
import IMAGES from '../../assets/Images';
import { CustomText } from '../../components/CustomText';
import { horizontalScale, verticalScale } from '../../utils/Metrics';
import { onePaliWorksProps } from '../../typings/routes';
import { ScrollView } from 'react-native-gesture-handler';
import styles from './styles';
import CustomIcon from '../../components/CustomIcon';
import ICONS from '../../assets/Icons';
import PrimaryButton from '../../components/PrimaryButton';
import FocusResetScrollView from '../../components/FocusResetScrollView';

const fundImages = [IMAGES.KidsImage, IMAGES.kidsImageOne];

const fundCards = [
  {
    id: '1',
    title: 'Claim a number',
    description: 'Starts a $1 monthly subscription to hold your number.',
  },
  {
    id: '2',
    title: 'Collective impact',
    description: 'Small monthly contributions that add up when shared.',
  },
  {
    id: '3',
    title: 'Get Updated',
    description: 'See how funds are used, shared in the app with photos.',
  },
];

const OnePaliWorks: FC<onePaliWorksProps> = ({navigation}) => {

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        <FocusResetScrollView
          showsVerticalScrollIndicator={false}
          bounces={false}
          contentContainerStyle={styles.contentContainer}
        >
          <Image source={IMAGES.OnePaliLogo} style={styles.appIcon} />

          {/* HEADER */}
          <View style={styles.header}>
            <CustomText
              fontFamily="GabaritoSemiBold"
              fontSize={36}
              color={COLORS.darkText}
              style={styles.headerTitle}
            >
              One Cause, Shared Effort
            </CustomText>
            <CustomText
              fontFamily="SourceSansRegular"
              fontSize={15}
              color={COLORS.appText}
            >
              OnePali is a collective commitment. Each member contributes $1 per
              month. Together, those dollars add up.
            </CustomText>
          </View>

          {/* FUNDS LIST */}
          <ScrollView
            horizontal
            bounces={false}
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.fundsListContent}
          >
            {fundCards.map(item => (
              <View key={item.id} style={styles.fundCard}>
                <View style={styles.fundCardImage} />
                <CustomText
                  fontFamily="GabaritoMedium"
                  fontSize={18}
                  color={COLORS.darkText}
                  style={styles.fundCardTitle}
                >
                  {item.title}
                </CustomText>
                <CustomText
                  fontFamily="SourceSansRegular"
                  fontSize={15}
                  color={COLORS.appText}
                >
                  {item.description}
                </CustomText>
              </View>
            ))}
          </ScrollView>

          <View style={styles.divider} />

          <View style={styles.sectionContainer}>
            <CustomText
              fontFamily="GabaritoMedium"
              fontSize={22}
              style={styles.centerText}
            >
              Where funds are directed?
            </CustomText>

            <CustomText
              fontFamily="SourceSansRegular"
              fontSize={15}
              color={COLORS.appText}
              style={styles.sectionDescription}
            >
              Funds raised through OnePali are directed to Gaza through the
              Middle East Children's Alliance (MECA), a nonprofit delivering aid
              on the ground.
            </CustomText>

            <View style={styles.imageRow}>
              {fundImages.map((img, index) => (
                <Image
                  key={index}
                  source={img}
                  resizeMode="contain"
                  style={[styles.image, { width: '48%' }]}
                />
              ))}
            </View>
          </View>

          <View style={styles.sectionWrapper}>
            <CustomText
              fontFamily="GabaritoMedium"
              fontSize={22}
              style={styles.centerText}
            >
              Who’s working on what?
            </CustomText>
            <View style={styles.whoCard}>
              <View style={styles.rowContainer}>
                <CustomIcon Icon={ICONS.calenderIcon} width={24} height={24} />
                <View style={{ gap: verticalScale(4) }}>
                  <CustomText
                    fontFamily="GabaritoMedium"
                    fontSize={18}
                    color={COLORS.darkText}
                  >
                    OnePali
                  </CustomText>
                  <CustomText
                    fontFamily="SourceSansRegular"
                    fontSize={15}
                    color={COLORS.appText}
                  >
                    Organizes the collective and facilitates monthly
                    contributions.
                  </CustomText>
                </View>
              </View>

              <View style={styles.innerDivider} />
              <View style={styles.rowContainer}>
                <CustomIcon Icon={ICONS.truckIcon} width={24} height={24} />
                <View style={{ gap: verticalScale(4) }}>
                  <CustomText
                    fontFamily="GabaritoMedium"
                    fontSize={18}
                    color={COLORS.darkText}
                  >
                    MECA
                  </CustomText>
                  <CustomText
                    fontFamily="SourceSansRegular"
                    fontSize={15}
                    color={COLORS.appText}
                  >
                    Distributes aid on the ground and shares updates directly in
                    OnePali.
                  </CustomText>
                </View>
              </View>
            </View>
            <Image
              source={IMAGES.Image}
              resizeMode="contain"
              style={styles.bottomImage}
            />
            <View style={styles.sectionWrapper}>
              <CustomText
                fontFamily="GabaritoMedium"
                fontSize={22}
                style={styles.centerText}
              >
                How will I stay in the loop?
              </CustomText>

              <CustomText
                fontFamily="SourceSansRegular"
                fontSize={15}
                color={COLORS.appText}
                style={styles.sectionDescription}
              >
                Updates from Mecca are shared directly in the app. You’ll see
                how funds are being used over time. Occasional notifications
                highlight new updates.
              </CustomText>
            </View>
            <PrimaryButton
              title="Continue"
              onPress={() => {
                navigation.navigate('claimSpot');
              }}
              style={styles.primaryButton}
            />
          </View>
        </FocusResetScrollView>
      </SafeAreaView>
    </View>
  );
};

export default OnePaliWorks;
