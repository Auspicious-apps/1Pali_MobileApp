import {
  View,
  Image,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
  TouchableWithoutFeedback,
} from 'react-native';
import React, { useState, useRef, FC } from 'react';
import { SafeAreaView } from 'react-native-safe-area-context';

import IMAGES from '../../assets/Images';
import COLORS from '../../utils/Colors';
import { CustomText } from '../../components/CustomText';
import CustomIcon from '../../components/CustomIcon';
import ICONS from '../../assets/Icons';
import PrimaryButton from '../../components/PrimaryButton';
import styles from './styles';
import { ClaimSpotProps } from '../../typings/routes';

const ClaimSpot: FC<ClaimSpotProps> = ({navigation}) => {
  const [number, setNumber] = useState('');
  const [checking, setChecking] = useState(false);
  const [available, setAvailable] = useState(false);

  const typingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);
  const checkingTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleChange = (text: string) => {
    const numeric = text.replace(/[^0-9]/g, '');
    setNumber(numeric);

    if (typingTimeout.current) clearTimeout(typingTimeout.current);
    if (checkingTimeout.current) clearTimeout(checkingTimeout.current);

    if (!numeric.length) {
      setAvailable(false);
      setChecking(false);
      return;
    }

    typingTimeout.current = setTimeout(() => {
      setChecking(true);
      setAvailable(false);

      checkingTimeout.current = setTimeout(() => {
        setChecking(false);
        setAvailable(true);
      }, 3000);
    }, 1000);
  };

  return (
    <View style={styles.container}>
      <SafeAreaView style={styles.safeArea} edges={['top', 'bottom']}>
        <TouchableWithoutFeedback onPress={Keyboard.dismiss} accessible={false}>
          <KeyboardAvoidingView
            style={styles.keyboardView}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
          >
          <View style={styles.content}>
            <Image source={IMAGES.OnePaliLogo} style={styles.logo} />

            <View style={styles.headingContainer}>
              <CustomText
                fontFamily="GabaritoSemiBold"
                fontSize={42}
                color={COLORS.darkText}
              >
                Claim your spot
              </CustomText>
              <CustomText
                fontFamily="GabaritoRegular"
                fontSize={16}
                color={COLORS.appText}
                style={{ textAlign: 'center' }}
              >
                Each number represents 1 person
              </CustomText>
            </View>

            <View style={styles.inputWrapper}>
              <View style={styles.inputContainer}>
                <CustomText
                  fontFamily="GabaritoSemiBold"
                  style={styles.hashText}
                >
                  #
                </CustomText>

                <TextInput
                  style={styles.textInput}
                  value={number}
                  onChangeText={handleChange}
                  keyboardType="number-pad"
                  inputMode="numeric"
                  maxLength={7}
                />

                <CustomIcon Icon={ICONS.diceIcon} width={24} height={24} />
              </View>

              {checking ? (
                <View style={styles.statusRow}>
                  <CustomIcon Icon={ICONS.loader} width={16} height={16} />
                  <CustomText
                    fontFamily="GabaritoRegular"
                    fontSize={12}
                    color={COLORS.grey}
                  >
                    Checking...
                  </CustomText>
                </View>
              ) : available ? (
                <View style={styles.statusRow}>
                  <CustomIcon
                    Icon={ICONS.CheckMarkIcon}
                    width={16}
                    height={16}
                  />
                  <CustomText
                    fontFamily="GabaritoRegular"
                    fontSize={12}
                    color={COLORS.green}
                  >
                    Available
                  </CustomText>
                </View>
              ) : (
                <CustomText
                  fontFamily="GabaritoRegular"
                  fontSize={12}
                  color={COLORS.grey}
                >
                  #Pick a number between 1 and 1,000,000
                </CustomText>
              )}
            </View>
          </View>

          <PrimaryButton
            title="Claim spot"
            onPress={() => {
              navigation.navigate('missionIntro', { number });
            }}
            disabled={!available}
            style={styles.button}
          />
          </KeyboardAvoidingView>
        </TouchableWithoutFeedback>
      </SafeAreaView>
    </View>
  );
};

export default ClaimSpot;
