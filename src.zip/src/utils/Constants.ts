const STORAGE_KEYS = {
  isOnBoarded: 'isOnBoarded',
  deviceId: 'deviceId',
  fcmToken: 'fcmToken',
};

export default STORAGE_KEYS;
